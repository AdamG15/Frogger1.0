﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject[] stuff;
    public Transform SpawnPoint;
    float spawnWait;
    public float StartWait;
    public float SpawnMostWait;
    public float SpawnLeastWait;
    int randelement;
    void Start()
    {
        StartCoroutine(WaitSpawner());
    }
    void Update()
    {
        spawnWait=Random.Range(SpawnLeastWait,SpawnMostWait);    
    }
    IEnumerator WaitSpawner()
    {
        
        yield return new WaitForSeconds(StartWait);
        while(true){
            randelement =Random.Range(0,stuff.Length);
            Instantiate(stuff[randelement],SpawnPoint.position,SpawnPoint.rotation);
            yield return new WaitForSeconds(spawnWait);
        }
    }
}
