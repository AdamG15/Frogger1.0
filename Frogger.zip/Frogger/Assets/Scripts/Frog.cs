﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Frog : MonoBehaviour
{
    public float LeftBorder=-8;
    public float RightBorder=22;
    public Rigidbody2D rb;
    static int lives=3;
    // Update is called once per frame
    private void Start() {
        Debug.Log("Lives: "+lives);
    }
    void Update()
    {
        controler();
        gameOver();
    } 
    void gameOver(){
        if(lives<=0){
            Debug.Log("GameOver");
        }
    }
   void controler(){
         if(Input.GetKeyDown(KeyCode.RightArrow)){
             if(rb.position.x<22){
            rb.MovePosition(rb.position+Vector2.right);}
        }
        if(Input.GetKeyDown(KeyCode.LeftArrow)){
            if(rb.position.x>-8){
            rb.MovePosition(rb.position+Vector2.left);}
        }
        if(Input.GetKeyDown(KeyCode.UpArrow)){
            rb.MovePosition(rb.position+Vector2.up);
        }
         if(Input.GetKeyDown(KeyCode.DownArrow)){
             rb.MovePosition(rb.position+Vector2.down);
         }
   }
    void OnTriggerEnter2D(Collider2D other) {
        if(other.tag=="Car"){
            Death();
        }
       /*  if(other.tag=="Log"){
            //rb.MovePosition(rb.position+Car.doom);
        }*/
    }
    void Death(){
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
            lives--;
    }
}
